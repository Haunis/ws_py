def run():
    print("cat run")